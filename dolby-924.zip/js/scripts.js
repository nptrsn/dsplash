// Empty JS for your own code to be here

// Change Mailchimp placehoder
$( window ).load(function() {
  $( 'input#mce-EMAIL.email' ).attr("placeholder", "Sign up for our mailing list");
  $( 'input#mc-embedded-subscribe.button').attr('value','Join');
});